// Declaring Global Variables and using it in the whole program

var libTechBookNum=[]; 
var bookAvail=[];
var CheckoutBookNumIndex;
var CheckoutBookNum;
// Using onclick and declaring the function in the html 
function CheckingOut(checkoutForm){
    libTechBookNum= (JSON.parse(localStorage.getItem("libTecBookNumKey")))
    bookAvail = (JSON.parse(localStorage.getItem("BookTechKey")))
   
    if(libTechBookNum!=null){
        
        CheckoutBookNum = document.getElementById("BookNum").value
       
        CheckoutBookNumIndex = libTechBookNum.indexOf(CheckoutBookNum)
        
      if(CheckoutBookNumIndex>0){
            
            bookAvail[CheckoutBookNumIndex] = false;
            
        localStorage.setItem("BookTechKey", JSON.stringify(bookAvail));
        
            }
      
    }
}
