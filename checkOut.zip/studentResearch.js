// Declaration of variables
var bookNumStu;
var bookTitleStu;
var bookAuthorStu;
var bookFstu;
var bookNFstu;
var bookGNSstu;
var bookPubDatestu;
var bookGenreStu;
var bookNumPagestu;
var bookTitleLib = [];
var bookAuthorLib = [];
var bookNumLib = [];
var bookTypeLib = [];
var bookPubDateLib = [];
var bookGenreLib = [];
var bookDateId = [];
var bookPagesLib = [];
var bookImglib=[];
var counter = bookNumLib.length ;

// Function to display search results
function displayFinalResults() {
  // Retrieve values from local storage
  bookTitleStu = localStorage.getItem("stuTecBookNumKey2");
  bookAuthorStu = localStorage.getItem("stuTecBookNumKey4");
  bookFstu = localStorage.getItem("stuTecBookFKey");
  bookNFstu = localStorage.getItem("stuTecBookNFKey");
  bookGNSstu = localStorage.getItem("stuTecBookGNKey");
  bookPubDatestu = localStorage.getItem("stuTecBookNumKey6");
  bookGenreStu = localStorage.getItem("stuTecBookNumKey5");
  bookNumPagestu = localStorage.getItem("stuTecBookNumKey3");
  bookTitleLib = JSON.parse(localStorage.getItem("libTecBookNumKey5"));
  bookAuthorLib = JSON.parse(localStorage.getItem("libTecBookNumKey3"));
  bookNumLib = JSON.parse(localStorage.getItem("libTecBookNumKey"));
  bookTypeLib = JSON.parse(localStorage.getItem("libTecBookNumKey6"));
  bookPubDateLib = JSON.parse(localStorage.getItem("libTecBookNumKey2"));
  bookGenreLib = JSON.parse(localStorage.getItem("libTecBookNumKey4"));
  bookDateId = JSON.parse(localStorage.getItem("libTecBookNumKey2"));
  bookPagesLib = JSON.parse(localStorage.getItem("libTechBookNumKey8"));
  bookImglib =JSON.parse(localStorage.getItem("libTechBookNumKey9")); 

  var SearchResultsHolder = '';







  

  for (var i ; i < bookNumLib.length; i++) {
    // Construct the result string for each book
    var resultString =
      "Book Number: " + bookNumLib[i] + "<br>" +
      "Book Title: " + bookTitleLib[i] + "<br>" +
      "Book Author: " + bookAuthorLib[i] + "<br>" +
      "Number Of Pages: " + bookPagesLib[i] + "<br>" +
      "Genre of the Book: " + bookGenreLib[i] + "<br>" +
      "Publication Date: " + bookPubDateLib[i] +  "<br>" 
      
    // If there is one blank field and one of them is true it prints the book
    if(!bookNumStu || !bookTitleStu || !bookAuthorStu || !bookGenreStu || !bookNumPagestu || !bookPubDatestu || !bookFstu || !bookNFstu || !bookGNSstu ) {
      // Check if the current book matches the search criteria
      if (
        bookNumLib[i] == bookNumStu || bookAuthorLib[i] == bookAuthorStu || bookGenreStu == bookGenreLib[i] || bookPubDateLib[i] == bookPubDatestu || bookNumPagestu == bookPagesLib[i] || bookTitleStu == bookTitleLib[i] ||
        bookTypeLib[i] == bookFstu || bookTypeLib[i] == bookNFstu || bookTypeLib[i] == bookGNSstu
      ) 
        alert("Car1")
        // Add book information to the search results holder
        SearchResultsHolder += bookAuthorLib[i] + "<br>";
        SearchResultsHolder += bookGenreLib[i] + "<br>";
        SearchResultsHolder += bookPagesLib[i] + "<br>";
        SearchResultsHolder += bookPubDateLib[i] + "<br>";
        SearchResultsHolder += bookTitleLib[i] + "<br>";
        SearchResultsHolder += bookNumLib[i] + "<br>";
        SearchResultsHolder += bookTypeLib[i]+ "<br>"
        // Display the result string
        document.getElementById("bookResults").innerHTML = resultString;
      }
      alert("Car2")
      // This if statement is the opposite of the first one because if first if statement checks if there are multiple matches rather than checkihng if there 
      // are some of the field empty , But if some of the blank areas are left it still prints it .
    } else if (bookNumLib[i] == bookNumStu || bookAuthorLib[i] == bookAuthorStu || bookGenreStu == bookGenreLib[i] || bookPubDateLib[i] == bookPubDatestu || bookNumPagestu == bookPagesLib[i] || bookTitleStu == bookTitleLib[i]) {
      // Check if the current book matches the search criteria
      if (!bookNumStu || !bookTitleStu || !bookAuthorStu || !bookGenreStu || !bookNumPagestu || !bookPubDatestu) {
      

        SearchResultsHolder += bookAuthorLib[i] + "<br>";
        SearchResultsHolder += bookGenreLib[i] + "<br>";
        SearchResultsHolder += bookPagesLib[i] + "<br>";
        SearchResultsHolder += bookPubDateLib[i] + "<br>";
        SearchResultsHolder += bookTitleLib[i] + "<br>";
        SearchResultsHolder += bookNumLib[i] + "<br>";
        SearchResultsHolder += bookTypeLib[i]+ "<br>"
       
        // Display the result string
        document.getElementById("bookResults").innerHTML = resultString;
      }
      alert("Car3")
    }
    
    // This code prints the output if checked on the book type Non -  fiction and displays all the books related to that 
    else if (bookNumLib[i] == bookNumStu || bookAuthorLib[i] == bookAuthorStu || bookGenreStu == bookGenreLib[i] || bookPubDateLib[i] == bookPubDatestu || bookNumPagestu == bookPagesLib[i] || bookTitleStu == bookTitleLib[i] ||bookTypeLib [i]== bookNFstu ){
      
      SearchResultsHolder += bookAuthorLib[i] + "<br>";
      SearchResultsHolder += bookGenreLib[i] + "<br>";
      SearchResultsHolder += bookPagesLib[i] + "<br>";
      SearchResultsHolder += bookPubDateLib[i] + "<br>";
      SearchResultsHolder += bookTitleLib[i] + "<br>";
      SearchResultsHolder += bookNumLib[i] + "<br>";
      SearchResultsHolder += bookTypeLib[i]+ "<br>"
      
      // Display the result string
      document.getElementById("bookResults").innerHTML = resultString;
    }
     // This code prints the output if checked on the book type fiction and displays all the books related to that 
   else if (bookNumLib[i] == bookNumStu && bookAuthorLib[i] == bookAuthorStu && bookGenreStu == bookGenreLib[i] && bookPubDateLib[i] == bookPubDatestu && bookNumPagestu == bookPagesLib[i] && bookTitleStu == bookTitleLib[i] && bookTypeLib [i]== bookFstu){
    alert("Car4")
    SearchResultsHolder += bookAuthorLib[i] + "<br>";
    SearchResultsHolder += bookGenreLib[i] + "<br>";
    SearchResultsHolder += bookPagesLib[i] + "<br>";
    SearchResultsHolder += bookPubDateLib[i] + "<br>";
    SearchResultsHolder += bookTitleLib[i] + "<br>";
    SearchResultsHolder += bookNumLib[i] + "<br>";
    SearchResultsHolder += bookTypeLib[i]+ "<br>"
   
    
    // Display the result string
    document.getElementById("bookResults").innerHTML = resultString;
   }
    // This code prints the output if checked on the book type Graphic  and displays all the books related to that 
   else if (bookNumLib[i] == bookNumStu && bookAuthorLib[i] == bookAuthorStu && bookGenreStu == bookGenreLib[i] && bookPubDateLib[i] == bookPubDatestu && bookNumPagestu == bookPagesLib[i] && bookTitleStu == bookTitleLib[i] && bookTypeLib [i]== bookGNSstu  ){
    alert("Car5")
    SearchResultsHolder += bookAuthorLib[i] + "<br>";
    SearchResultsHolder += bookGenreLib[i] + "<br>";
    SearchResultsHolder += bookPagesLib[i] + "<br>";
    SearchResultsHolder += bookPubDateLib[i] + "<br>";
    SearchResultsHolder += bookTitleLib[i] + "<br>";
    SearchResultsHolder += bookNumLib[i] + "<br>";
    SearchResultsHolder += bookTypeLib[i]+ "<br>"
    
    // Display the result string
    document.getElementById("bookResults").innerHTML = resultString;
   }
   else {
    alert("There are no results")
    alert("Car6")
   }
  
}











//  We defined global variables here 




/*
var bookNumStu;
var bookTitleStu;
var bookAuthorStu;
var bookFstu;
var bookNFstu;
var bookGNSstu;
var bookPubDatestu;
var bookGenreStu
var bookNumPagestu;
var bookTitleLib=[];
var bookAuthorLib=[];
var bookNumLib=[];
var bookTypeLib=[];
var bookPubDateLib=[];
var bookGenreLib=[];
var bookDateId=[];
var bookPagesLib=[];
counter=0;

// We Tried get the results from the local storage and display it on to the search Results page

function displayResults(){
   
          bookNumStu=localStorage.getItem("stuTecBookNumKey");
          bookTitleStu=localStorage.getItem("stuTecBookNumKey2");
          bookAuthorStu=localStorage.getItem("stuTecBookNumKey4");
          bookFstu  =localStorage.getItem("stuTecBookFKey")
           bookNFstu=localStorage.getItem("stuTecBookNFKey");
           bookGNSstu=localStorage.getItem("stuTecBookGNKey")
           bookGenreStu=localStorage.getItem("stuTecBookNumKey5")
           bookNumPagestu=localStorage.getItem("stuTecBookNumKey3");
           bookTitleLib=localStorage.getItem("libTecBookNumKey5");
           bookAuthorLib=localStorage.getItem("libTecBookNumKey3");
           bookNumLib=localStorage.getItem("libTecBookNumKey");
           bookTypeLib=localStorage.getItem("libTecBookNumKey6")
           bookPubDateLib=localStorage.getItem("libTecBookNumKey2");
           bookGenreLib =localStorage.getItem("libTecBookNumKey4");
           bookDateId=localStorage.getItem("libTecBookNumKey2");
   bookPagesLib=localStorage.getItem("libTechBookNumKey8")      
}

// I tried to display the search in one paragraph and tried to display it using the variable string .
   
     document.getElementById("search").innerHTML=bookNumLib
     document.getElementById("search").innerHTML=bookTitleLib
     document.getElementById("search").innerHTML=bookAuthorLib
//This string displays the search results using one paragraph
    
// The following code helps to get the id and display itfunction displayFinalResults(){
     bookTitleStu=(localStorage.getItem("stuTecBookNumKey2"));
          bookAuthorStu=localStorage.getItem("stuTecBookNumKey4");
          bookFstu  =localStorage.getItem("stuTecBookFKey")
           bookNFstu=localStorage.getItem("stuTecBookNFKey");
           bookGNSstu=localStorage.getItem("stuTecBookGNKey")
           bookPubDatestu= localStorage.getItem("stuTecBookNumKey6")
           bookGenreStu=localStorage.getItem("stuTecBookNumKey5")
           bookNumPagestu=(localStorage.getItem("stuTecBookNumKey3"));
           bookTitleLib=JSON.parse(localStorage.getItem("libTecBookNumKey5"));
           bookAuthorLib=JSON.parse(localStorage.getItem("libTecBookNumKey3"));
           bookNumLib=JSON.parse(localStorage.getItem("libTecBookNumKey"))
           bookTypeLib=JSON.parse(localStorage.getItem("libTecBookNumKey6"))
           bookPubDateLib=JSON.parse(localStorage.getItem("libTecBookNumKey2"));
           bookGenreLib =JSON.parse(localStorage.getItem("libTecBookNumKey4"));
           bookDateId=JSON.parse(localStorage.getItem("libTecBookNumKey2"));
        bookPagesLib=JSON.parse(localStorage.getItem("libTechBookNumKey8"))

        var SearchResultsHolder='';
          
          var resultString = "Book Number :" + bookNumLib + "<br>" + "Book Title :" + bookTitleLib + "<br>" + "book author" + bookAuthorLib + bookPagesLib + "<br>"+"Number Of Pages:"+bookGenreLib + "<br>"+"Genre of the Book:"+bookPubDateLib+"<br>"+"Publication Date";
          document.getElementById("bookResults").innerHTML = resultString;          
        for(var i = 0 ; i <bookNumLib.length ;i++){
          var resultString = "Book Number :" + bookNumLib + "<br>" + "Book Title :" + bookTitleLib + "<br>" + "Book Author" + bookAuthorLib +"<br>"+ bookPagesLib +"Number Of Pages:"+"<br>"+ bookGenreLib + "<br>"+"Genre of the Book:"+bookGenreLib+"<br>"+"Publication Date"+ bookPubDateLib;
        

          if (bookNumLib[i]==bookNumStu&&bookTitleLib[i]===bookTitleStu&&bookAuthorStu===bookAuthorLib[i]&&bookPagesLib[i]===bookNumLib&&bookGenreStu===bookGenreLib[i]&&bookPubDateLib[i]===bookPubDatestu&&bookTypeLib[i]===bookFstu){
               document.getElementById("bookResults").innerHTML = resultString;}
          else if(bookNumLib[i]===bookNumStu&&bookTitleLib[i]===bookTitleStu&&bookAuthorStu===bookAuthorLib[i]&&bookPagesLib[i]===bookNumLib&&bookGenreStu===bookGenreLib[i]&&bookPubDateLib[i]===bookPubDatestu&&bookTypeLib[i]===bookNFstu){
               document.getElementById("bookResults").innerHTML = resultString;}
          else if (bookNumLib[i]===bookNumStu&&bookTitleLib[i]===bookTitleStu&&bookAuthorStu===bookAuthorLib[i]&&bookPagesLib[i]===bookNumLib&&bookGenreStu===bookGenreLib[i]&&bookPubDateLib[i]===bookPubDatestu&&bookTypeLib[i]===bookNFstu){
          document.getElementById("bookResults").innerHTML = resultString;
     }
             else{
                 alert("Sorry there are no results") 
               }
     
          }}



          for (var i = 0; i < bookNumLib.length; i++) {
               var resultString =
                 "Book Number: " + bookNumLib[i] + "<br>" +
                 "Book Title: " + bookTitleLib[i] + "<br>" +
                 "Book Author: " + bookAuthorLib[i] + "<br>" +
                 "Number Of Pages: " + bookPagesLib[i] + "<br>" +
                 "Genre of the Book: " + bookGenreLib[i] + "<br>" +
                 "Publication Date: " + bookPubDateLib[i];
          if (!bookNumStu|| !bookTitleStu|| bookAuthorStu||bookGenreStu||bookNumPagestu||bookPubDatestu||bookFstu||bookNFstu||bookGNSstu){
               if (bookNumLib[i]==bookNumStu||bookAuthorLib[i]==bookAuthorStu||bookGenreStu== bookGenreLib[i]||bookPubDateLib[i]==bookPubDatestu||bookNumPagestu==bookPagesLib[i]||bookTitleStu==bookTitleLib[i]||
                    bookTypeLib[i]==bookFstu||bookTypeLib[i]==bookNFstu||bookTypeLib[i]==bookGNSstu){
                   SearchResultsHolder += bookAuthorLib[i] + "<br>";
                   SearchResultsHolder += bookGenreLib[i] + "<br>";
                   SearchResultsHolder += bookPagesLib[i] + "<br>";
                   SearchResultsHolder += bookPubDateLib[i] + "<br>";
                   SearchResultsHolder +=  bookTitleLib[i] + "<br>";
                   SearchResultsHolder += bookNumLib[i] + "<br>";



                         document.getElementById("bookResults").innerHTML = resultString;
                    }
          } else if (bookNumLib[i]==bookNumStu||bookAuthorLib[i]==bookAuthorStu||bookGenreStu== bookGenreLib[i]||bookPubDateLib[i]==bookPubDatestu||bookNumPagestu==bookPagesLib[i]||bookTitleStu==bookTitleLib[i]){
                   if(!bookNumStu|| !bookTitleStu|| bookAuthorStu||bookGenreStu||bookNumPagestu||bookPubDatestu){
                    document.getElementById("bookResults").innerHTML = resultString;
                   }
          }}}
          /*
               if (
                 bookNumLib[i] === bookNumStu &&
                 bookTitleLib[i] === bookTitleStu &&
                 bookAuthorLib[i] === bookAuthorStu &&
                 bookPagesLib[i] === bookNumStu &&
                 bookGenreLib[i] === bookGenreStu &&
                 bookPubDateLib[i] === bookPubDatestu &&
                 bookTypeLib[i] === bookFstu
               ) {
                 document.getElementById("bookResults").innerHTML = resultString;
               } else if (
                 bookNumLib[i] === bookNumStu &&
                 bookTitleLib[i] === bookTitleStu &&
                 bookAuthorLib[i] === bookAuthorStu &&
                 bookPagesLib[i] === bookNumStu &&
                 bookGenreLib[i] === bookGenreStu &&
                 bookPubDateLib[i] === bookPubDatestu &&
                 bookTypeLib[i] === bookNFstu
               ) {
                 document.getElementById("bookResults").innerHTML = resultString;
               } else if (
                 bookNumLib[i] === bookNumStu &&
                 bookTitleLib[i] === bookTitleStu &&
                 bookAuthorLib[i] === bookAuthorStu &&
                 bookPagesLib[i] === bookNumStu &&
                 bookGenreLib[i] === bookGenreStu &&
                 bookPubDateLib[i] === bookPubDatestu &&
                 bookTypeLib[i] === bookNFstu
               ) {
                 document.getElementById("bookResults").innerHTML = resultString;
               } else {
                 alert("Sorry, there are no results.");
               }
             }}
        
        if (!bookNumStu || bookNumLib === bookNumStu) {
          SearchResultsHolder += bookNumLib
          if (!bookTitleStu|| bookTitleLib === bookTitleStu) {
              if (!bookAuthorStu || bookAuthorLib === bookAuthorStu) {
                      if (!bookPubDatestu || bookPubDateLib === bookPubDatestu) {
                          if (bookTypeLib === bookFstu || bookNFstu|| bookGNSstu) {
                              document.getElementById('bookResults').innerHTML = resultString;+++++++
                          }
                      }
                  }
              }
          }else{
               alert('There are no results found')
          }}}*/
