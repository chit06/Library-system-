var libTechBookNum=[];
var libTechTitle=[];
var libPubDate=[];
var libBookType=[];
var libTechAuthor=[];
var libTechType=[];
var libDateAdd=[];
var libNumPages=[];
var libGenre=[];
var bookAvail
var deleteBooknum;
var deleteBooknumIndex;

function deleteBook(deleteForm){
    bookTitleLib = JSON.parse(localStorage.getItem("libTecBookNumKey5"));
    bookAuthorLib = JSON.parse(localStorage.getItem("libTecBookNumKey3"));
    bookNumLib = JSON.parse(localStorage.getItem("libTecBookNumKey"));
    bookTypeLib = JSON.parse(localStorage.getItem("libTecBookNumKey6"));
    bookPubDateLib = JSON.parse(localStorage.getItem("libTecBookNumKey2"));
    bookGenreLib = JSON.parse(localStorage.getItem("libTecBookNumKey4"));
    bookDateId = JSON.parse(localStorage.getItem("libTecBookNumKey2"));
    bookPagesLib = JSON.parse(localStorage.getItem("libTechBookNumKey8"));
    bookAvail = (JSON.parse(localStorage.getItem("BookTechKey")))
    

    
    if (libTechBookNum!=null){
        returnBookNum = document.getElementById("bookno").value
        deleteBooknumIndex= libTechBookNum.indexOf(deleteBooknum)
        
    }
    libTechBookNum.splice(delete1)
}