var StuBookNum;
var StuTechTitle;
var StuTecHNumberofpages;
var StuTechAuthor;
var StuTechGenre;
var StucanPubdate;
var stuBookTypeF;
var stuBookTypeNFS;
var stuBookTypeGNS;




function getStudentSearchData(searchBookForm){
    StuBookNum = searchBookForm.bookNumS.value;
    StuTechTitle = searchBookForm.bookTitleY.value;
    StuTecHNumberofpages = searchBookForm.PNumber.value;
    StuTechAuthor= searchBookForm.authorL.value;
    StuTechGenre = searchBookForm.genreC.value;
    StucanPubdate = searchBookForm.pubDateL.value;
    stuBookTypeF= searchBookForm.bookTypeFS.checked;
    stuBookTypeNFS= searchBookForm.bookTypeNFS.checked;
    stuBookTypeGNS= searchBookForm.bookTypeGNS.checked;


 if (stuBookTypeF){
  stuBookTypeF="Fiction"
 }
 if(stuBookTypeGNS){
  stuBookTypeGNS="Graphic"
 }
 if(stuBookTypeNFS){
  stuBookTypeNFS="Non-Fiction"
 }
    localStorage.setItem('stuTecBookNumKey', StuBookNum)
    localStorage.setItem('stuTecBookNumKey2',  StuTechTitle)
    localStorage.setItem('stuTecBookNumKey3',  StuTecHNumberofpages)
    localStorage.setItem('stuTecBookNumKey4',  StuTechAuthor )
    localStorage.setItem('stuTecBookNumKey5',   StuTechGenre)
    localStorage.setItem('stuTecBookNumKey6', StucanPubdate )
    localStorage.setItem('stuTecBookFKey',   stuBookTypeF)
    localStorage.setItem('stuTecBookNFKey',   stuBookTypeNFS)
    localStorage.setItem('stuTecBookGNKey',   stuBookTypeGNS)

}
