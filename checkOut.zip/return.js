var libTechBookNum=[]; 
var bookAvail=[];
var returnBookNumIndex;
var returnBookNum;
// Using onclick and declaring the function in the html 
function returnBk(returnoutForm){
    libTechBookNum= (JSON.parse(localStorage.getItem("libTecBookNumKey")))
    bookAvail = (JSON.parse(localStorage.getItem("BookTechKey")))
   
    if(libTechBookNum!=null){
       
        returnBookNum = document.getElementById("bookNum").value
        
        returnBookNumIndex = libTechBookNum.indexOf(returnBookNum)
       
      // if(libTechBookNum>0){
            
            bookAvail[returnBookNumIndex] = true;
          
        localStorage.setItem("BookTechKey", JSON.stringify(bookAvail));
        
            }
      
    }
  